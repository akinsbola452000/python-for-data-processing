### this question is pretty difficult and could not get the code working"


import csv
from datetime import datetime
from StringIO import StringIO
from collections import namedtuple
from pyspark import SparkConf, SparkContext

DATE_FMT = ""%Y-%m-%d%H:%M:%S"
bus_spe = namedtuple('time","lineRef","speed")

def parse(row):
    row[0] = datetime.strptime(row[4],DATE_FMT)
    row[14] = int(row[14])
    return bus_spe(*row)

def split(line):
    reader = cvs.reader(StringIO(line))
    return reader.next()

def box_plt(lineRef, time):
    import matplotlib as mpl
    mpl.use('Agg')
    import matplotlib.pyplot as plt

bus_box = sc.wholetextFile("/user/student/bus_data").map(split).map(parse).filter(box_plt) 		
